using BankManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace BankManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DatabaseConnection _databaseConnection;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            _databaseConnection = new DatabaseConnection();
        }

        public IActionResult home()
        {
            return View();
        }

        public IActionResult details()
        {
            return View();
        }

        public IActionResult about()
        {
            return View();
        }

        public IActionResult signup()
        {
            return View();
        }
        [Route("accdetails")]
        public IActionResult accdetails()
        {
            var model = _databaseConnection.GetAllSignups();
            return View(model);
        }

        [Route("AccountDetails")]
        public IActionResult AccDetails()
        {
            List<Signup> signups = _databaseConnection.GetAllSignups();
            ViewBag.UserCount = signups.Count;
            return View(signups);
        }



        public IActionResult admin()
        {
            return View();
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
