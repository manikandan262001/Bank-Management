﻿using BankManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using System.Data;

namespace BankManagementSystem.Controllers
{
    public class DetailController : Controller
       
    {
       
        private readonly DatabaseConnection _databaseConnection;
        public DetailController()
        {
            _databaseConnection = new DatabaseConnection();
        }

        [HttpPost]
        public ActionResult SaveData(string Firstname, string Lastname, string Username, string Password, int Accountno)
        {
            try
            {
                using (var conn = _databaseConnection.GetConnection())
                {
                    MySqlCommand cmd = new MySqlCommand("INSERT INTO Signup (Firstname, Lastname, Username, Password, Accountno) VALUES (@Firstname, @Lastname, @Username, @Password, @Accountno)", conn);
                    cmd.Parameters.AddWithValue("@Firstname", Firstname);
                    cmd.Parameters.AddWithValue("@Lastname", Lastname);
                    cmd.Parameters.AddWithValue("@Username", Username);
                    cmd.Parameters.AddWithValue("@Password", Password);
                    cmd.Parameters.AddWithValue("@Accountno", Accountno);
                    cmd.ExecuteNonQuery();
                }
                return Json(new { success = true, message = "Data saved successfully" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }




       


        [HttpPost]
        public ActionResult Login(string Username, string Password)
        {
            try
            {
                using (var conn = _databaseConnection.GetConnection())
                {
                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM Signup WHERE Username = @Username AND Password = @Password", conn);
                    cmd.Parameters.AddWithValue("@Username", Username);
                    cmd.Parameters.AddWithValue("@Password", Password);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            // User exists, password is correct
                            return Json(new { success = true, message = "Login successful" });
                        }
                        else
                        {
                            // User does not exist or password is incorrect
                            return Json(new { success = false, message = "Invalid username or password" });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }


    }
}
