document.getElementById('login-form').addEventListener('submit', function (event) {
    event.preventDefault();

    // Get form field values
    var name = document.getElementById('username-input').value;
    var password = document.getElementById('password-input').value;
    var error = false;


    // If validation passes, you can now use these variables in your code
    console.log('Username:', name);
    console.log('Password:', password);

    if (!error) {
        $.ajax({
            type: 'POST',
            url: '/Detail/Login',
            data: {
                Username: name,
                Password: password
            },
            success: function (response) {
                if (response.success) {
                    console.log('Data is sent to the server');
                    alert("Login Successful");
                    window.location.href = '/Home/details';
                    console.log('data sent.');
                } else {
                    alert(response.message);
                }
            },
            error: function (xhr, status, error) {
                console.error("Error sending :", error);
                alert("Login Failed");
            }
        });
    }
});