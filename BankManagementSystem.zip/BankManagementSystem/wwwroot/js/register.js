document.getElementById('signup-form').addEventListener('submit', function (event) {
   event.preventDefault();

    // Get form field values
    var firstname = document.getElementById('firstname-input').value;
    var lastname = document.getElementById('lastname-input').value;
    var username = document.getElementById('username-input').value;
    var password = document.getElementById('password-input').value;
    var accountno = document.getElementById('account-number-input').value;
    var error = false;

    // Validation checks
    if (!/^[A-Za-z\s]+$/.test(firstname)) {
        alert('Name should only contain alphabets.');
        error = true;
    }
    if (!/^[A-Za-z\s]+$/.test(lastname)) {
        alert('Name should only contain alphabets.');
        error = true;
    }
    if (!/^[A-Za-z\s]+$/.test(username)) {
        alert('Name should only contain alphabets.');
        error = true;
    }
    if (!/^(?=.*[A-Z])(?=.*[!@#$%^&*]).{5,10}$/.test(password)) {
        alert('Password should be 5 to 8 length long with one capital letter and one special character.');
        error = true;
    }
    if (!/^\d{5}$/.test(accountno)) {
        alert('Provide a valid Account Number. It must be exactly 5 digits long.');
        error = true;
    }


    // If validation passes, you can now use these variables in your code
    console.log('Firstname:', firstname);
    console.log('Lastname:', lastname);
    console.log('Username:', username);
    console.log('Password:', password);
    console.log('Accountno:', accountno);

    if (!error) {
        

        $.ajax({
            type: 'POST',
            url: '/Detail/SaveData',
            data: {
                firstname: firstname,
                lastname: lastname,
                username: username,
                password: password,
                accountno: accountno
            },
            success: function (response) {
                console.log('Data is sent to the server');
                alert("User Account has been successfully created.");
                window.location.href = '/Home/home';
                console.log('data sent.');
            
            },
            error: function (xhr, status, error) {
                console.error("Error sending :", error);
                alert("Not created");
            }
        });
        
    }
});

    
