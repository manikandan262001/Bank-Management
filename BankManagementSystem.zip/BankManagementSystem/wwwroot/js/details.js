﻿var myAccountBalance = parseInt(document.getElementById("my-account-balance").innerText);



function sendmoney() {

    var myAccountBalance = parseInt(document.getElementById("my-account-balance").innerText);
    var enterAccount = document.getElementById("enter-account").value;
    var enterAmount = parseInt(document.getElementById("enter-amount-transfer").value);
    var notrans = document.getElementById("notransaction").innerText;

    if (enterAmount > myAccountBalance) {
        alert("Insufficient Balance");
    }
    else if (enterAmount == 0) {
        alert("Please enter a valid amount")
    }
    else {

        var myAccountBalance = parseInt(document.getElementById("my-account-balance").innerText) - enterAmount;
        document.getElementById("my-account-balance").innerText = myAccountBalance;

        alert(`Successful Transaction !!  
      ₹${enterAmount} is sent to ${enterAccount} Account Number.`);
        if (notrans == "No transaction") {
            document.getElementById("notransaction").innerText = "";
        }

        var createTag = document.createElement("li");
        var date = new Date();
        var formattedDate = date.toLocaleTimeString('en-US', { hour12: false });
        var text = document.createTextNode(`Credited ₹${enterAmount} to Account No ${enterAccount} on ${formattedDate}.`);

        createTag.appendChild(text);
        var element = document.getElementById("transaction-ol");
        element.insertBefore(createTag, element.firstChild);
    }


}
function depositmoney() {
    var enterAmount = parseInt(document.getElementById("enter-amount-deposit").value);
    var notrans = document.getElementById("notransaction").innerText;
    var enterdepositAmount = parseInt(document.getElementById("enter-amount-deposit").value);



    if (enterAmount == 0) {
        alert("Please enter a valid amount")
    }
    else if (enterAmount == "NaN") {
        alert("Please enter amount")
    }
    else {
        if (notrans == "No transaction") {
            document.getElementById("notransaction").innerText = "";
        }
        var myAccountBalance = parseInt(document.getElementById("my-account-balance").innerText) + enterdepositAmount;
        document.getElementById("my-account-balance").innerText = myAccountBalance;
        alert(`Successful Transaction !!  
    ₹${enterdepositAmount} is deposited to your Account.`);

        var createTag = document.createElement("li");
        var date = new Date();
        var formattedDate = date.toLocaleTimeString('en-US', { hour12: false });
        var text = document.createTextNode(`Deposited ₹${enterAmount} in your Bank Account on ${formattedDate}.`);

        createTag.appendChild(text);
        var element = document.getElementById("transaction-ol");
        element.insertBefore(createTag, element.firstChild);
    }

}





