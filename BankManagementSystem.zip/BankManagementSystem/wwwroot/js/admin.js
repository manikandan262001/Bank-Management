﻿const adminuser = "mani";
const adminpass = "mani";

function login(event) {
    var username = document.getElementById("username-input").value;
    var password = document.getElementById("password-input").value;

    if (username != adminuser && password == adminpass) {
        event.preventDefault();
        alert("Invalid Username");
    }
    if (username != adminuser && password != adminpass) {
        event.preventDefault();
        alert("Unauthorized Access");

    }
    if (username == adminuser && password != adminpass) {
        event.preventDefault();
        alert("Incorrect Password");
    }
    if (username == adminuser && password == adminpass) {
        window.location.href = "accdetails.html";
    }
}
