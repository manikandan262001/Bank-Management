﻿// BankManagementSystem/Models/Signup.cs

namespace BankManagementSystem.Models
{
    public class Signup
    {
        public int Id { get; set; }
        public string? Firstname { get; set; } // Now nullable
        public string? Lastname { get; set; } // Now nullable
        public string? Username { get; set; } // Now nullable
        public string? Password { get; set; } // Now nullable
        public string? Accountno { get; set; } // Now nullable
    }

}
