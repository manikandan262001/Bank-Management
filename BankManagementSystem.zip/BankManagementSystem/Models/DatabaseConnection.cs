﻿// BankManagementSystem/Models/DatabaseConnection.cs

using BankManagementSystem.Controllers;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace BankManagementSystem.Models
{
    public class DatabaseConnection
    {
        private readonly string connectionString = "Server=localhost;Database=BankManagementSystem;Uid=root;Pwd=root;";

        public MySqlConnection GetConnection()
        {
            MySqlConnection conn = new MySqlConnection(connectionString);
            conn.Open();
            return conn;
        }

        public List<Signup> GetAllSignups()
        {
            List<Signup> signups = new List<Signup>();

            using (MySqlConnection conn = GetConnection())
            {
                MySqlCommand cmd = new MySqlCommand("select * from Signup", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        signups.Add(new Signup()
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Firstname = reader["Firstname"].ToString(),
                            Lastname = reader["Lastname"].ToString(),
                            Username = reader["Username"].ToString(),
                            Accountno = reader["Accountno"].ToString()
                        });
                    }
                }
            }

            return signups;
        }
        public Signup GetLatestSignup()
        {
            Signup signup = new Signup();

            using (MySqlConnection conn = GetConnection())
            {
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM Signup ORDER BY Id DESC LIMIT 1", conn);

                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        signup = new Signup()
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Firstname = reader["Firstname"].ToString(),
                            Lastname = reader["Lastname"].ToString(),
                            Username = reader["Username"].ToString(),
                            Accountno = reader["Accountno"].ToString()
                        };
                    }
                }
            }

            return signup;
        }


    }
}
